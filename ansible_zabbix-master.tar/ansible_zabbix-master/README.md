# 使用ansible编译安装zabbix3.0.4 server端和agent端

